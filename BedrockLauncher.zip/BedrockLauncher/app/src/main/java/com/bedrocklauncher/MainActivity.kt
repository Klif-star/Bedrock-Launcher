package com.bedrocklauncher

import android.app.Activity
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.util.zip.ZipInputStream

class MainActivity : Activity() {

    private val mcPackage = "com.mojang.minecraftpe"
    private val reqGame = 1
    private val reqAddon = 2
    private lateinit var listBox: LinearLayout

    private val versionsDir get() = File(filesDir, "versions").also { it.mkdirs() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Bedrock Launcher"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "Pasang APK Minecraft Bedrock milikmu sendiri dan impor addon tanpa lewat Play Store."
            textSize = 13f
            setPadding(0, dp(4), 0, dp(12))
        })
        root.addView(button("Impor APK / APKS / XAPK") { pick(reqGame) })
        root.addView(button("Impor Addon (.mcaddon .mcpack .mcworld)") { pick(reqAddon) })
        root.addView(button("Buka Minecraft") { launchMinecraft() })

        root.addView(TextView(this).apply {
            text = "Mod bawaan"
            textSize = 16f
            setPadding(0, dp(16), 0, dp(4))
        })
        root.addView(TextView(this).apply {
            text = "Risk! Mod bisa ditolak atau memicu ban di server publik. " +
                "Pakai atas risiko sendiri."
            setTextColor(Color.RED)
            setTypeface(typeface, Typeface.BOLD)
            textSize = 14f
            setPadding(0, 0, 0, dp(8))
        })
        val mods = (assets.list("mods") ?: emptyArray()).sorted()
        for (m in mods) {
            val label = m.removeSuffix(".mcpack").replace('_', ' ')
                .replaceFirstChar { it.uppercase() }
            root.addView(button("Impor: $label") { importBundled(m) })
        }

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(TextView(this).apply {
            text = "File terimpor"
            textSize = 16f
            setPadding(0, dp(16), 0, dp(4))
        })
        root.addView(listBox)

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun pick(code: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, code)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { c -> for (n in 0 until c.itemCount) uris.add(c.getItemAt(n).uri) }
        data.data?.let { uris.add(it) }

        Thread {
            for (uri in uris) {
                val name = displayName(uri)
                if (requestCode == reqGame) {
                    val ok = name.endsWith(".apk", true) || name.endsWith(".apks", true) || name.endsWith(".xapk", true)
                    if (!ok) { toast("Dilewati (bukan APK/APKS/XAPK): $name"); continue }
                    copyTo(uri, File(versionsDir, name))
                } else {
                    val dir = File(cacheDir, "addons").also { it.mkdirs() }
                    val f = File(dir, name)
                    copyTo(uri, f)
                    runOnUiThread { openInMinecraft(f) }
                }
            }
            runOnUiThread { refresh() }
        }.start()
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    private fun copyTo(uri: Uri, dest: File) {
        contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { input.copyTo(it) }
        }
    }

    private fun refresh() {
        listBox.removeAllViews()
        val files = versionsDir.listFiles()?.sortedBy { it.name } ?: emptyList()
        if (files.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "Belum ada file." })
            return
        }
        for (f in files) {
            val info = if (f.name.endsWith(".apk", true)) {
                packageManager.getPackageArchiveInfo(f.path, 0)
                    ?.let { "${it.packageName} v${it.versionName}\n" } ?: ""
            } else ""
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(8), 0, dp(8))
            }
            row.addView(TextView(this).apply {
                text = "${f.name}\n$info${f.length() / 1024 / 1024} MB"
            })
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.START
            }
            actions.addView(button("Pasang") { install(f) })
            actions.addView(button("Hapus") { f.delete(); refresh() })
            row.addView(actions)
            listBox.addView(row)
        }
    }

    private fun install(file: File) {
        if (!packageManager.canRequestPackageInstalls()) {
            toast("Izinkan 'pasang aplikasi tidak dikenal' untuk launcher ini, lalu coba lagi.")
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return
        }
        Thread {
            try {
                val installer = packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                val id = installer.createSession(params)
                installer.openSession(id).use { s ->
                    if (file.name.endsWith(".apk", true)) {
                        s.openWrite("base.apk", 0, file.length()).use { out ->
                            file.inputStream().use { it.copyTo(out) }
                            s.fsync(out)
                        }
                    } else {
                        var n = 0
                        ZipInputStream(file.inputStream()).use { zin ->
                            var e = zin.nextEntry
                            while (e != null) {
                                if (e.name.endsWith(".apk", true)) {
                                    s.openWrite("split$n.apk", 0, -1).use { out ->
                                        zin.copyTo(out)
                                        s.fsync(out)
                                    }
                                    n++
                                }
                                e = zin.nextEntry
                            }
                        }
                        if (n == 0) { toast("Tidak ada APK di dalam ${file.name}"); s.abandon(); return@Thread }
                    }
                    val pi = PendingIntent.getBroadcast(
                        this, id, Intent(this, InstallReceiver::class.java),
                        PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    s.commit(pi.intentSender)
                }
            } catch (e: Exception) {
                toast("Gagal: ${e.message}")
            }
        }.start()
    }

    private fun openInMinecraft(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            setPackage(mcPackage)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("Minecraft belum terpasang.")
        }
    }

    private fun importBundled(name: String) {
        Thread {
            try {
                val dir = File(cacheDir, "addons").also { it.mkdirs() }
                val f = File(dir, name)
                assets.open("mods/$name").use { input ->
                    f.outputStream().use { input.copyTo(it) }
                }
                runOnUiThread { openInMinecraft(f) }
            } catch (e: Exception) {
                toast("Gagal: ${e.message}")
            }
        }.start()
    }

    private fun launchMinecraft() {
        val i = packageManager.getLaunchIntentForPackage(mcPackage)
        if (i != null) startActivity(i) else toast("Minecraft belum terpasang.")
    }
}
